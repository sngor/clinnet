# This file makes the 'appointments' directory a Python package
